Folder assets untuk Parlay Calculator

Isi:
assets/
├── teams       -> logo negara
├── background  -> gambar stadion/background
└── icons       -> icon aplikasi

Tambahkan file logo PNG ke folder teams.
